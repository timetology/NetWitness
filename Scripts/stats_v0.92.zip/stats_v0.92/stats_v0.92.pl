#!/usr/bin/perl
use IO::Socket::SSL qw();
use LWP::UserAgent qw();
use Date::Calc qw(Delta_Days Today_and_Now);
use Date::Parse;
use Number::Format;
use Getopt::Long;
use Excel::Writer::XLSX;
use Pod::Usage;
use MIME::Lite;
use XML::Simple qw(:strict); # Needed for 10.6
use JSON qw( decode_json );
require 'utf8_heavy.pl';


#===================================================================================
# Written by: Keven Murphy (RSA IR)
#
# stats.pl --gear {devices.csv} --outfile {output in csv}  
#          --stack --verbose
#
# --gear {devices.csv} This contains the list of gear in a CSV formated file as shown below
# https,ipaddress,50005,userid,password,concentrator
# http,ipaddress,50003,userid,password,broker
#
# --outputfile {output in csv} Send the output to this file
# --stack      Puts the word "stack" in the output
# --verbose    Sends the screen all sorts of output as the script runs
# --stripe     Stripes the XLSX table output 
# --aio        Assume gear is a AIO box
#
# Email Output
# --from {email address} [Optional]
# --to {email address} 
# --subject {subject}
# --emailfile [Optional]
#
# Compiling Notes:
# Activestate Perl 
# * Install the modules listed above
# * cpanp i Win32::Exe PAR::Packer
# Strawberry Perl
# * It compiled but wouldn't reference the libwinpthread-1.dll library when running as a exe.
#
# To compile:
# pp -o stats.exe -a c:\Strawberry\perl\bin\libwinpthread-1.dll -a libeay32__.dll 
# -a zlib1__.dll -a ssleay32__.dll   stats.pl 
#
# Author Notes:
# 1) Need to do a clean up of the code a bit.
#
# Mod Log:
# 10/07/14 -- Added code for Log decoders
# 10/30/14 -- Added date checking for valid dates
# 06/02/16 -- Added CSV deliminator and email
# 03/20/18 -- Re-added concentrator checks in case there was no broker
# 07/22/19 -- Handles case where broker points to brokers
# 09/29/20 -- adjust to work with 11.5
#===================================================================================

#Default Output Filename
my $outfile = "stats_".sprintf("%4d-%02d-%02d_%02d%02d%02d", Today_and_Now()).".csv";
my $outfilexls = "stats_".sprintf("%4d-%02d-%02d_%02d%02d%02d", Today_and_Now()).".xlsx";
my $subjectstat = "_".sprintf("%4d-%02d-%02d_%02d%02d%02d", Today_and_Now());

my $version = "0.92 WR Edition";
my $csvdelim = ",";

my $xlsrow = 0;
my $brcnt = -1;

#Default Ports
$lport = "50002";  #Log Decoder
$bport = "50003";
$cport = "50005";
$dport = "50004";
$lport2 = "56002";
$lrestport = "50102";  # Log Decoder
$brestport = "50103";
$crestport = "50105";
$drestport = "50104";
$lportnew = "56002";  #Log Decoder
$bportnew = "56003";
$cportnew = "56005";
$dportnew = "56004";

#$verbose = 0;

%mon2num = ('jan'=>'01',
        'feb'=>'02',
		'mar'=>'03',
		'apr'=>'04',
		'may'=>'05',
		'jun'=>'06',
		'jul'=>'07',
		'aug'=>'08',
		'sep'=>'09',
		'oct'=>'10',
		'nov'=>'11',
		'dec'=>'12'
);

		
#Decoder
my %decoderstat = ();
$decoderstat{'service.name'} = '/sys/stats/service.name';
$decoderstat{'capture.status'} = '/decoder/stats/capture.status';
$decoderstat{'capture.dropped'} = '/decoder/stats/capture.dropped';
$decoderstat{'capture.dropped.percent'} = '/decoder/stats/capture.dropped.percent';
$decoderstat{'capture.rate'} = '/decoder/stats/capture.rate';
$decoderstat{'capture.rate.max'} = '/decoder/stats/capture.rate.max';
$decoderstat{'packet.oldest.file.time'} = '/database/stats/packet.oldest.file.time';
$decoderstat{'bpf'} = '/decoder/config/rules/bpf';
$decoderstat{'parser.count'} = '/decoder/parsers/stats/parser.count';
$decoderstat{'feed.count'} = '/decoder/parsers/stats/feed.count';
#Concentrator
my %concstat = ();
$concstat{'service.name'} = '/sys/stats/service.name';
$concstat{'meta.oldest.file.time'} = '/database/stats/meta.oldest.file.time';
#Broker
my %brokerstat = ();
$brokerstat{'service.name'} = '/sys/stats/service.name';
$brokerstat{'time.begin'} = '/index/stats/time.begin';
$brokerstat{'version'} = '/sys/stats/version';




sub DateDiff {
    my ($date) = @_;
    my @date_tmp = split(/s+/, $date);
    my ($year, $month, $day) = split(/-/,$date_tmp[0]);
    $month = $mon2num{ lc substr($month, 0, 3) };
    my @metadate = ($year, $month, $day);
    my @today = (localtime)[5,4,3];
    $today[0] += 1900;
    $today[1]++;

    my $days = Delta_Days(@metadate, @today);
    return($days);	
}

sub humannum {
  my ($num) = @_;
  my $formatted = "";
  
  if (length($num) > 6) {
  
  my $de = new Number::Format(thousands_sep   => '',
                              decimal_point   => '.',
			      KILO_SUFFIX     => ' thousand',
			      MEGA_SUFFIX     => ' million',
			      GIGA_SUFFIX     => ' billion');
   $formatted = $de->format_bytes($num, base => 1000);
  } else {
    $formatted = $num; 
  }
  
  return($formatted);
}

sub getport {
	my ($port,$geartype) = @_;
	#my ($port,$crap) = split(/ /,$porttmp);
        my $portlen = length($port);
	if ($portlen > 5) {
		print "Got a bad port: $port\n";
		exit(1);
	}
	$portstart = substr($port, 0, 1);
	if ($portstart eq "5") {
		$portend = substr($port, -1);
	    if ($portend eq '2') { # Log Decoder
			$port = $lrestport;
			$geartype = "log decoder";
	    }
	    if ($portend eq '3') { # Broker
			$port = $brestport;
			$geartype = "broker";
	    }
	    if ($portend eq '4') { # Decoder
			$port = $drestport;
			$geartype = "decoder";
	    }
	    if ($portend eq '5') { # Concentrator
			$port = $crestport;
			$geartype = "concentrator";
	    }
	}
	return($port,$geartype);
}

sub GetStat {
	my ($device,$port,$user,$pass,$comtype,$urlpath) = @_;
	my $geartype = "";

	($port, $geartype) = getport($port,$geartype);

	my $box = $device.':'.$port;
	$browser->credentials($box,'NetWitness',$user,$pass);
	my $url = $comtype.'://'.$box.$urlpath.'?force-content-type=text/plain';
	print "Get Stat 1 URL: $url\n" if $verbose;
	my $response = $browser->get($url);
	$response->is_success or warn $response->status_line;  
	$response->decoded_content;
	if ($response->status_line =~ /^500/) {
	   if ($comtype eq "https") {
	       $url = "http".'://'.$box.$urlpath.'?force-content-type=text/plain';
	      } else {
		   $url = "https".'://'.$box.$urlpath.'?force-content-type=text/plain';
		}
		print "GetStat 2 URL: $url\n" if $verbose;
		$response = $browser->get($url);
		$response->is_success or warn $response->status_line;
		$response->decoded_content;
		print "\n";
	}
	
	if ($response->status_line =~ /^500/) {
		return("Gear is down");
    }	
	my @url_response = split(/\\n/, $response->decoded_content);
	chomp(@url_response);
	$returnvar = $response->decoded_content;
	$returnvar =~ s/\s+\z//g;
	return($returnvar);
}

sub GetGear {
	my ($device,$port,$user,$pass,$comtype,$urlpath) = @_;
	my $geartype = "";
	
	($port, $geartype) = getport($port,$geartype);

        print "== GetGear ==\n" if $verbose;   
    
	my $box = $device.':'.$port;
	$browser->credentials($box,'NetWitness',$user,$pass);
	my $url = $comtype.'://'.$box.'/'.$geartype.$urlpath.'?force-content-type=application/json';
	print "GetGear 1 URL: $url\n" if $verbose;
	my $response = $browser->get($url);
	$response->is_success or warn $response->status_line."\nNote: Ignore 500 Error (GetGear)\n";
	if ($response->status_line =~ /^500/) {
	   if ($comtype eq "https") {
	       $url = "http".'://'.$box.'/'.$geartype.$urlpath.'?force-content-type=application/json';
	      } else {
		   $url = "https".'://'.$box.'/'.$geartype.$urlpath.'?force-content-type=application/json';
		}
		print "Get Gear 2 URL: $url\n" if $verbose;
		$response = $browser->get($url);
		$response->is_success or warn $response->status_line;
	}
    
	if ($response->status_line =~ /^401/) {
	    print "ERROR: 401 --  Bad user id or password\n";
		print "Cannot continue.";
		exit(0);
	}

	if ($response->status_line =~ /^200/) {
	
		my $decoded = decode_json($response->decoded_content);
		my @sagear =  @{ $decoded->{nodes} };

		#foreach my $f ( @sagear ) {
		#   print "C: ".$f->{"path"} . "\n";
		#}
		
		my $brcnt = -1;
		#for (my $i=0; $i <= $arrcnt; $i++) {
		
		my $deviceversion = GetStat($device,$port,$user,$pass,$comtype,$brokerstat{'version'});
		print "Version:$deviceversion\n" if $verbose;
		my @versionnum = split('\.',$deviceversion);
		print "DV: $device,$port,$user,$pass,$comtype,$brokerstat{'version'}\n";
		
		foreach my $f ( @sagear ) {
			#changed to work with 11.5
			if ($versionnum[0] >= 11 and $versionnum[1] >= 5) { 
			#if (exists $f->{"display"} && length $f->{"display"} > 0) {
			    $gearline = $f->{"display"};
			  } else {
			    $gearline = $f->{"path"};
			}

			#my $gearline = $config->{nodes}->{node}->{path};
			#changed to work with 11.5
			if ($versionnum[0] >= 11 and $versionnum[1] >= 5) {			
			#if (exists $f->{"display"} && length $f->{"display"} > 0) {
			    $deviceipport = $gearline;
			  } else {
			    ($notneeded1,$device,$notneeded2,$deviceipport) = split(/\//,$gearline);
			}
			#my ($deviceip,$port) = split(/:/, $deviceipport);
			#print "C: $deviceipport\n";
			$brcnt++;
			$url_response[$brcnt] = $deviceipport;
		}
	}
	
	return(\@url_response);
}

sub PrintError {
    my ($error) = @_;
    chomp ($error);
	print "ERROR: DATE is invalid.\n";
	print "Returned: \"".$error."\"\n\n" if $verbose;
}

sub printrowxlsx {
	my ($worksheet,$formatrow,$formatrowstrip,$row,$col,$text) = @_;
	if ($nostripe) {
		$worksheet->write($row,$col,$text,$formatrow);
	  } else {
		if (0 == $row % 2) {
			$worksheet->write($row,$col,$text,$formatrowstrip);
		  } else {
			$worksheet->write($row,$col,$text,$formatrow);
		}
	}	
	return($worksheet);
}

sub GoodPort {
    # Check to see if we have a concentrator port
	my ($port) = @_;
	my $confnd = 0;
	if ($port eq $cport) {
		$confnd++;
	}
	if ($port eq $crestport) {
		$confnd++;
	}
	if ($port eq $cportnew) {
		$confnd++;
	}
	return($confnd);
}

sub geartop {
    my ($broker_response_temp,$user,$pass,$fh,$comtype,$worksheet,$workbook,$nwcolorstripe,$formatrow,$formatrowstrip) = @_;
	my @broker_response = @$broker_response_temp;

	foreach $gear (@broker_response) {
		$gear =~ s/^\s+|\s+$//g;
		$gear =~ s/ =$//g;  #stipping off these characters due to 10.4 SA
		@box = split(/:/, $gear);
		my $confnd = GoodPort($box[1]);
		if ($confnd >= 1) {
				my $servicename = GetStat($box[0],$box[1],$user,$pass,$comtype,'/sys/stats/service.name');
				print "\nService Name: $servicename";
				if ($servicename eq "Gear is down") {
				    print " $box[0]\n";
					#Increase row counter for XLSX
					$xlsrow++;
					my $xlscol = 0;

					my $stack = $servicename." (".$box[0].") => ". $dservicename." (".$dboxes[0].")";
					print $fh $stack.",";
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$stack);
				
					print $fh "0,";  #Capturing number
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"0");
					
					print $fh "-,"; #Packet loss
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");
										
					print $fh "-,"; #Live content deployed
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");
	
					print $fh "-,"; #IR content deployed
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");
					
					print $fh "-,";
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");
					
					print $fh "0".","."0".","; #Capture rates
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"0");
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"0");
					
					print $fh "-,"; # Packet retention
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");
					
					print $fh "-,";
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");

					#Decoder device version
					print $fh "-,"; #Device Version	
					$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"-");						
					
					print $fh "\n";					
					next;
				  } else {
				    print "\n";
				}
				
				
				
				my $con_meta_date = "";
				my $conf_meta_diff = "";
				eval { $con_meta_date = GetStat($box[0],$box[1],$user,$pass,$comtype,'/database/stats/meta.oldest.file.time'); };
				if ( $@ ) { 
				    PrintError($con_meta_date);
				    $con_meta_diff = "Error";
				  } else {
				    eval { $conc_meta_diff = DateDiff($con_meta_date);  };
				    if ($@) {
				       PrintError($conc_meta_diff);
				       $con_meta_diff = "Error";
				    }
				}
				
				my @decoder_gear = ();
			
				$arry_ref = GetGear($box[0],$box[1],$user,$pass,$comtype,"/devices");
				@decoder_gear = @$arry_ref;
				
				print $fh "$servicename stack\n" if $stack;
				
				foreach $dgear (@decoder_gear) {
					$dgear =~ s/^\s+|\s+$//g;
					@dboxes = split(/:/, $dgear);
					if ($dboxes[0] ne "") {
					    my $dmeta_date = "";
						my $decoder_meta_diff= "";
						
						if ($dboxes[0] =~ /localhost/) {
							$dboxes[0] =~ s/localhost/$box[0]/;
						}
						
						eval { $dmeta_date = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/database/stats/packet.oldest.file.time'); };
						if ( $@ ) { 
						   PrintError(); 
						   $decoder_meta_diff = "Error";
						  } else {
						    print "Returned: $dmeta_date\n" if $verbose;
						    eval { $decoder_meta_diff = DateDiff($dmeta_date);  };
						    if ($@) {
						      PrintError();
						      $decoder_meta_diff = "Error";
						    }
						}
						
						my $dservicename = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/sys/stats/service.name');
						print "Returned: dservicename\n" if $verbose;
						
												
						$dmeta_date = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/database/stats/packet.oldest.file.time');
						my $dstatus = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/stats/capture.status');
						print "Returned: $dstatus\n" if $verbose;
						my $dcaptrec = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/stats/capture.received');
						print "Returned: $dcaptrec\n" if $verbose;
						my $ddropped = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/stats/capture.dropped'); 
						print "Returned: $ddropped\n" if $verbose;
						#my $ddroppedpercent = GetStat($dboxes[0],$dboxes[1],$user,$pass,'/decoder/stats/capture.dropped.percent'); # Returns erronous data
						my $ddroppedpercent = 0;
						if ($ddropped != 0) {
						   $ddroppedpercent = ($ddropped / $dcaptrec)*100;
						}
						$ddroppedpercent = int($ddroppedpercent)."%";
						my $dcaptrate = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/stats/capture.rate');
						print "Returned: $dcaptrate\n" if $verbose;
						my $dcaptratemax = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/stats/capture.rate.max'); 
						print "Returned: $dcaptratemax\n" if $verbose;
						my $dbpf = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/config/rules/bpf');
						print "Returned: $dbpf\n" if $verbose;
						my $dparsercnt = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/parsers/stats/parser.count');
						print "Returned: $dparsercnt\n" if $verbose;
						my $dfeedcnt = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,'/decoder/parsers/stats/feed.count');
						print "Returned: $dfeedcnt\n" if $verbose;
						my $deviceversion = GetStat($dboxes[0],$dboxes[1],$user,$pass,$comtype,$brokerstat{'version'});
						print "Returned: $deviceversion\n" if $verbose;
						
						
						#Increase row counter for XLSX
						$xlsrow++;
						my $xlscol = 0;

						my $stack = $servicename." (".$box[0].") => ". $dservicename." (".$dboxes[0].")";
						print $fh $stack.",";
						#my $xlstmp = $dservicename." (".$dboxes[0].")";
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$stack);
						#$worksheet->write($xlsrow,0,$dservicename."(".$dboxes[0].")",$formatrow);
						
						my $xlstmp = "";
						if ($dstatus eq "started") {
							print $fh "Yes; ";
							$xlstmp .= "Yes; ";
						  } else {
							print $fh "No; ";
							$xlstmp .= "No; ";
						}

						my $tmp = humannum($dcaptrec);
						my ($hnum,$humannum) = split(/ /,$tmp);
						if ($humannum eq "billion" && $hnum > 1000) {
							$hnum = $hnum / 100;
							$hnum = sprintf("%.2f", $hnum);
							print $fh "$hnum";
						    $xlstmp .= $hnum;
							print $fh " trillion,";   #Capturing number
							$xlstmp .= " trillion";
						  } else {	
						    print $fh $tmp.",";  #Capturing number
							$xlstmp .= $tmp;
						}
						
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$xlstmp);
						#$worksheet->write($xlsrow,1,$xlstmp,$formatrow);
						
						$tmp = humannum($ddropped);
						print $fh $tmp." ".$ddroppedpercent.","; #Packet loss
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$tmp." ".$ddroppedpercent);
						#$worksheet->write($xlsrow,2,$tmp." ".$ddroppedpercent,$formatrow);
						
					
						print $fh "Yes,"; #Live content deployed
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"Yes");
						#$worksheet->write($xlsrow,3,"Yes",$formatrow);
						
		
						print $fh "Yes,"; #IR content deployed
						#$worksheet->write($xlsrow,4,"Yes",$formatrow);
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"Yes");
						
			
						if ($dbpf ne "") {
							print $fh $dbpf.",";
							#$worksheet->write($xlsrow,5,$dbpf,$formatrow);
							$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$dbpf);
						  } else {
							print $fh "No,";
							#$worksheet->write($xlsrow,5,"No",$formatrow);
							$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"No");
						} # Filtering
						
				
						print $fh $dcaptrate.",".$dcaptratemax.","; #Capture rates
						#$worksheet->write($xlsrow,6,$dcaptrate,$formatrow);
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$dcaptrate);
						#$worksheet->write($xlsrow,7,$dcaptratemax,$formatrow);
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$dcaptratemax);
						
				
						print $fh $dmeta_date." (~".$decoder_meta_diff." days),"; # Packet retention
						#$worksheet->write($xlsrow,8,$dmeta_date." (~".$decoder_meta_diff." days)",$formatrow);
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$dmeta_date." (~".$decoder_meta_diff." days)");
						
						if ($con_meta_date eq "Gear is down") {
						      print $fh "Gear is down".",";
							  $worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"Gear is down");
							} else {
							  print $fh $con_meta_date." (~".$conc_meta_diff." days)".","; # meta retention
						      $worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$con_meta_date." (~".$conc_meta_diff." days)");
						      #$worksheet->write($xlsrow,9,$con_meta_date." (~".$conc_meta_diff." days)",$formatrow);
						}

						#Decoder device version
						print $fh $deviceversion.","; #Device Version	
						$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,$deviceversion);						
						
						#my $geartype = "";
						#my ($port, $geartype) = getport($dboxes[1],$geartype);
						#print $fh ",".$geartype;  # Gear type
						print $fh "\n";
						#$worksheet = printrowxlsx($worksheet,$formatrow,$formatrowstrip,$xlsrow,$xlscol++,"");
					}
				}
		}
		#print $fh "\n";
	}

}

sub brokerdevices {
    my ($broker_response_temp,$comtype,$gearip,$gearport,$geartype,$user,$pass,$equiptype,$deviceid) = @_;
	my @broker_response = @$broker_response_temp;

    if ($gearport eq "50003" || $gearport eq "56003" || $gearport eq "50103") {
    
        $gearport = "50103"; #Broker
        my $gearipport = $gearip.":".$gearport;
        #print "$comtype,$gearip,$gearport,$geartype,$user,$pass\n";
        $browser->credentials($gearipport,'NetWitness',$user,$pass);
        my $url = $comtype."://".$gearipport.'/'.$geartype.'/devices?force-content-type=application/json';
        print "Main URL: $url\n" if $verbose;
        my $response = $browser->get($url);
        $response->is_success or warn $response->status_line."\nNote: Ignore 500 Error (brokerdevices)\n";
		if ($response->status_line =~ /^401/) {
		   print "ERROR: 401 --  Bad user id or password (brokerdevices)\n";
		   print "Cannot continue.";
		   exit(0);
	    }
        $response->decoded_content;

        my $decoded = decode_json($response->decoded_content);
        my @sagear =  @{ $decoded->{nodes} };
        #print "Number of nodes: @sagear\n" if $verbose;
        

        
        my $brcnt = -1;
        

        my $deviceversion = GetStat($gearip,$gearport,$user,$pass,$comtype,$brokerstat{'version'});
		print "Version:$deviceversion\n" if $verbose;
        my @versionnum = split('\.',$deviceversion);
 
        if ($verbose) {
            print "==Broker: Devices Returned==\n";
            foreach my $f ( @sagear ) {
			    if ($versionnum[0] >= 11 and $versionnum[1] >= 5) {
					print "Devices:".$f->{"display"} . "\n";
				} else {
					print "Devices:".$f->{"path"} . "\n";
				}
            }
        }

 
        foreach my $f ( @sagear ) {
            #changed to work with 11.5

            if ($versionnum[0] >= 11 and $versionnum[1] >= 5) {           
#	    if (exists $f->{"display"} && length $f->{"display"} > 0 ) {
	        $gearline = $f->{"display"};
	        #print "display:*".$f->{"display"}."*\n";
	      } else {
	        $gearline = $f->{"path"};
	        #print "path:*".$f->{"path"}."*\n";
	    }

            #my $gearline = $config->{nodes}->{node}->[$i]->{path};
            #print "Gearline:$gearline\n";
            #changed to work with 11.5
            if ($versionnum[0] >= 11 and $versionnum[1] >= 5) {               
	    #if (exists $f->{"display"} && length $f->{"display"} > 0) {
	        $deviceipport = $gearline;
	      } else {
	        ($notneeded1,$device,$notneeded2,$deviceipport) = split(/\//,$gearline);
	    }

	
 
            #my ($deviceip,$port) = split(/:/, $deviceipport);
            print "\tDevice to contact:" if $verbose;
            #print "G:$notneeded1,$device,$notneeded2,$deviceipport\n";
            print $deviceipport."\n" if $verbose;
            $brcnt++;
            $broker_response[$brcnt] = $deviceipport;
        }
        
    }
    if ($gearport eq "50005" || $gearport eq"56005" || $gearport eq "50105") {
        $brcnt++;
        $broker_response[$brcnt] = $gearip.":".$gearport;
    }
    return (\@broker_response);
}


GetOptions("gear=s"	=> \$infile,
		"outfile=s"  => \$outfile,
		"stack" 	=> \$stack,
		"csvfield=s" => \$csvdelim,
		"aio" 	=> \$aio,
		"nostripe"	=> \$stripe,
		"to=s"	=> \$to,
		"from=s"	=> \$from,
		"subject=s"	=> \$subject,
		"smtpserver=s" => \$smtpserver,
		"smtpuser=s" => \$smtpuser,
		"smtppass=s" => \$smtppass,
		"emailfile=s" => \$emailfile,
		"help"	=> \$help,
		"man"	=> \$man,
		"verbose"    => \$verbose) ||  pod2usage(-verbose => 0);
		      
   Pod::Usage::pod2usage( -verbose => 1 ) if ( $help );
   Pod::Usage::pod2usage( -exitstatus => 0, -verbose => 2 ) if ( $man  );

if ($subject) {
	$subject = $subject . $subjectstat;
}
   
print "NetWitness Stats\n";
print "Version: $version\n";
print "Saving CSV to: $outfile\n";
print "Saving XLSX to: $outfilexls\n";	 
print "Using the following CSV deliminator for the gear file: $csvdelim\n";
if (-e $infile) {
  } else {
    print "\n\nYou did not supply a file with gear list.\n";
    print "\n\t$0 --gear {filename of the gear list}\n\n";
    print "Contents of the gear file should be:\n";
    print "https,ipaddress,50005,concentrator,userid,password,,\n";
    print "http,ipaddress,50003,broker,userid,password,,\n";
    exit(1);
}

#=======================================================================================
# Setup Output Files
#=======================================================================================
#write output CSV file
open(my $fh, '>', $outfile) or die "Could not open file '$outfile' $!";
print $fh "Stack,Capturing,Packet Loss,Live Content,IR Content,Filtering,Line Rate,Max Line Rate,Packet Retention,Meta Retention,Decoder Device Version\n"; # Header

#Setup XLSX sheet
#row,column,token,format for the write statements
my $workbook = Excel::Writer::XLSX->new($outfilexls);
my $worksheet = $workbook->add_worksheet();
#XLSX Formatting Setup 
my $nwcolorstripe = $workbook->set_custom_color(15,217,217,217);
my $formatrow = $workbook->add_format(
	align => 'center',
	bg_color => 9,
);
$formatrow->set_align('vcenter');
$formatrow->set_text_wrap(1);
$formatrow->set_font('Times New Roman');
$formatrow->set_size(8);
my $formatrowstrip = $workbook->add_format(
	bg_color  => $nwcolorstripe,
	align     => 'center',
);
$formatrowstrip->set_align('vcenter');
$formatrowstrip->set_text_wrap(1);
$formatrowstrip->set_font('Times New Roman');
$formatrowstrip->set_size(8);
my $nwcolor = $workbook->set_custom_color(16,184,204,228);
my $formattitle = $workbook->add_format(
	bg_color  => $nwcolor,
	align     => 'center',
	bold      => 1,
);
$formattitle->set_align('vcenter');
$formattitle->set_text_wrap(1);
$formattitle->set_font('Times New Roman');
$formattitle->set_size(8);
$worksheet->write(0,0,"Location",$formattitle);
$worksheet->write(0,1,"Capturing",$formattitle);
$worksheet->write(0,2,"Packet Loss",$formattitle);
$worksheet->write(0,3,"Live Content",$formattitle);
$worksheet->write(0,4,"IR Content",$formattitle);
$worksheet->write(0,5,"Filtering",$formattitle);
$worksheet->write(0,6,"Line Rate",$formattitle);
$worksheet->write(0,7,"Max Line Rate",$formattitle);
$worksheet->write(0,8,"Packet Retention",$formattitle);
$worksheet->write(0,9,"Meta Retention",$formattitle);
$worksheet->write(0,10,"Decoder Device Version",$formattitle);	
#=======================================================================================
#=======================================================================================


$browser = LWP::UserAgent->new(ssl_opts => {
    SSL_verify_mode => IO::Socket::SSL::SSL_VERIFY_NONE,
    verify_hostname => 0, # this key is likely going to be removed in future LWP >6.04
});



#Read in CSV file
open(my $infh, '<', $infile) or die "Could not open file '$infile' $!";
# $comtype,$gearip,$gearport,$geartype,$user,$pass  #my version
my ($comtype,$gearip,$gearport,$geartype,$user,$pass,$equiptype,$deviceid) = "";



while ( my $line = <$infh> ) {
	#chomp($line);
        $line =~ s/\r|\n//g;
	if ($line =~ /\s+/) {
		#next;
	}
	if ($line =~ /^#/) {
	   } else {
	    my (@geararray) = split(/,/,$line);
		#Rui: comtype, deviceip, deviceRestPort, Username, Passwd, Equipment type, deviceid
		#Me:  comtype, deviceip, deviceRestPort, username, passwd

		($comtype,$gearip,$gearport,$user,$pass,$geartype,$deviceid) = split(/$csvdelim/,$line);
		#$comptype = "http"; # Hard setting this for now. Script will try both http and https

		if ( $geartype ~~ ['broker', 'concentrator', 'decoder','log decoder'] ) {
		    } else {
			  print "\nA-Format of the CSV files needs to be: http,{ip of gear},{port},{userid},{password},{broker,concetrator,decoder}\n";
			  print "Example: http,127.0.0.1,50003,userid,password,broker\n";
			  exit(0);
		}
		print "User: $user\n";
		print "Pass: $pass\n";
		my @broker_response;
		my $broker_response_temp = brokerdevices(\@broker_response,$comtype,$gearip,$gearport,$geartype,$user,$pass,$equiptype,$deviceid);
		my @broker_response = @$broker_response_temp;
		foreach my $device (@broker_response) {
		  my ($ip,$port) = split(/:/,$device);
		  print "IP: $ip   GIP: $gearip\n" if $verbose;
		  if ($ip ne $gearip) {
		     if ($port eq "50003" || $port eq "56003" || $port eq "50103") {
		        my @broker_response_new;
		        my $broker_response_temp = brokerdevices(\@broker_response_new,$comtype,$ip,$port,$geartype,$user,$pass,$equiptype,$deviceid);
		        my @broker_response_new = @$broker_response_temp;
		        push(@broker_response,@broker_response_new);
		     }
		  }
		}
		geartop(\@broker_response,$user,$pass,$fh,$comtype,$worksheet,$workbook,$nwcolorstripe,$formatrow,$formatrowstrip);
		
	}
}

$workbook->close();
close($fh);
close($infh);

#Send out the output files
if ($to) {
	if ($from) {
	  } else {
	   $from = "rsa@rsa.com";
	}
	
	$MIME::Lite::AUTO_CONTENT_TYPE = 1;
    my $message = "Attached is: ".$outfile.", ".$outfilexls;
	
	#-- create the multipart container 
	my $msg = MIME::Lite->new (
	From     => $from,
	To       => $to,
	Subject  => $subject,
	Type     =>'multipart/mixed'
	) or die "Error creating multipart container: $!\n";

	#-- add the text message part 
	$msg->attach (
	Type => 'TEXT',
	Data => $message,
	) or die "Error adding the text message part: $!\n";

	#-- add the ZIP file 
	$msg->attach (
	Type        => 'AUTO',
	Path        => $outfile,
	Filename    => $outfile,
	Disposition => 'attachment'
	) or die "Error adding $outfile: $!\n";
	#-- add the ZIP file 
	$msg->attach (
	Type        => 'AUTO',
	Path        => $outfilexls,
	Filename    => $outfilexls,
	Disposition => 'attachment'
	) or die "Error adding $outfilexls: $!\n";	

    print "\n\nEmail\n" if $verbose;
	$msg->print_header(\*STDOUT) if $verbose;
	$msg->print_body(\*STDOUT) if $verbose;
	
	if ($smtpserver) {
	    $msg->send('smtp', $smtpserver, Timeout=>60, AuthUser=>$smtpuser, AuthPass=>$smtppass) or die "Error: Sending email$!\n";
	  } else {
	    $msg->send or die "Error: Sending email$!\n";
    }
	
	
	
	#SMTP Server
	#my $smtp = Net::SMTP_auth -> new( $smtpserver );
	#$smtp -> auth( 'LOGIN', 'z', 'ztest' );

	#$smtp->mail('z@zentara.zentara.net');
	#$smtp->to($to);
	#$smtp -> data();
	#$smtp -> datasend( $msg->as_string() );
	#$smtp -> dataend();
}

__END__

=head1 stats

Generates Stats for NW gear

=head1 SYNOPSIS

Use:

stats.pl --gear {filename}

=head1 DESCRIPTION

B<stats.pl> Generates Stats for NW gear

=head1 ARGUMENTS

Listed below are the availabe arguments:

=over 4

=item B<--gear {filename}>

--gear {filename}

B<(REQUIRED)> CSV file with gear information (http/https,IP,port,type,userid,password)

=item B<--output {filename}>

--outfile {filename}

B<(Optional)> Filename of the output

=item B<--csvfield {character}>

--csvfield {Character}	

B<(Optional)> Change CSV deliminator for passwords that have a , in them

=item B<--verbose>
--verbose  Makes the script chatty

=item ----------------------------------

=item B<EMAIL Options (Optional)> Email output

=item B<--from {email address} [Optional]>

=item B<--to {email address}>

=item B<--subject {subject}>

=item B<--smtpserver {IP Address}>

=item B<--smtpuser {user id if required}>

=item B<--smtppass {password if required}>

=back

=head1 B<EXAMPLE>

./stats --gear devices.csv --from rsa@rsa.com --to rsa@rsa.com --subject test --smtpserver 10.X.X.1

=over

=back

=head1 OPTIONS

=over 8

=item B<--help>

Print a brief help message and exits.

=item B<--man>

Prints the manual page and exits.

=back


=cut
